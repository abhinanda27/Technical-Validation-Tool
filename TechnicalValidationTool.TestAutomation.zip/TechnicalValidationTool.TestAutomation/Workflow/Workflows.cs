﻿using OpenQA.Selenium;
using System;
using System.Collections.Generic;
using System.Text;
using TechnicalValidationTool.TestAutomation.Base;
using TechnicalValidationTool.TestAutomation.Page;
using TechnicalValidationTool.TestAutomation.CommonMethod;
using Xunit;
using System.Threading;
using OpenQA.Selenium.Support.UI;
using System.Linq;

namespace TechnicalValidationTool.TestAutomation.Workflow
{
   public class Workflows:PageBase
    {
        private static IWebDriver webDriver;
                
        public Workflows(IWebDriver driverInstance)
        {
            webDriver = driverInstance;
        }

        //public void googleTest1()
        //{
        //   //new GooglePage(webDriver).NaviagateToGoogle();
        //   new GooglePage(webDriver).searchBox.SendKeys("wewewewewwwwwwwwwwwww");
        //   System.Threading.Thread.Sleep(2000);
        //  Assert.False(true);
        //}

        //public void googleTest2()
        //{
        //    new GooglePage(webDriver).NaviagateToGoogle();
        //    new GooglePage(webDriver).searchBox.SendKeys("pppppppppppppppppppppppppp");
        //    System.Threading.Thread.Sleep(2000);
        //    //Assert.False(true);
        //}

        public void BVT_Pagination_Test(Object value)
        {
            new XPOD_HomePage_Header(webDriver).Login_XPOD(value);
            new XPOD_HomePage_Xpodlist(webDriver).Method_SelectViewValue(value, "BVT_TestData", "Viewname").ScrollTillEnd().Pagination_validation();         
        }
        public void BVT_HomepageField_Validation(Object DataObj)
        {
            new XPOD_HomePage_Header(webDriver).Login_XPOD(DataObj).Field_Validations();           
            new XPOD_HomePage_Xpodlist(webDriver).Method_FieldValidations().Method_SelectViewValue(DataObj, "BVT_TestData", "Viewname");
        }
        public void BVT_SeachFunction_Validations(Object DataObj)
        {
            new XPOD_HomePage_Header(webDriver).Login_XPOD(DataObj);
            new XPOD_HomePage_Xpodlist(webDriver).Method_Enter_SearchElement(DataObj).searchfunction(DataObj);
        }

        public void BVT_GenralTab_feild_Validations(Object DataObj)
        {
            new XPOD_HomePage_Header(webDriver).Login_XPOD(DataObj);
            new XPOD_HomePage_Xpodlist(webDriver).First_tableEle_Click().General_RIFeild_Validations();
            new XPOD_Genral_OI_Page(webDriver).General_OIFeild_Validations();
        }

        public void BVT_Notes_Section_Validations(Object DataObj)
        {
            new XPOD_HomePage_Header(webDriver).Login_XPOD(DataObj);
            new XPOD_HomePage_Xpodlist(webDriver).First_tableEle_Click().Switching_GeneralBasePage().Clicking_NotesTab().Creating_Notes(DataObj).CreatedNote_Validation(DataObj);
            
        }
        public void BVT_Activites_Tab_Validations(Object DataObj)
        {
            new XPOD_HomePage_Header(webDriver).Login_XPOD(DataObj);
            new XPOD_HomePage_Xpodlist(webDriver).Method_SelectViewValue(DataObj, "BVT_TestData", "Viewname").First_tableEle_Click().Switching_GeneralBasePage().Clicking_ActivitesTab().Activity_Table_Generation_Validation();
        }

        public void Installation_SecValidation(Object DataObj)
        {
            new XPOD_HomePage_Header(webDriver).Login_XPOD(DataObj);
            new XPOD_HomePage_Xpodlist(webDriver).Method_SelectViewValue(DataObj, "BVT_TestData", "Viewname").First_tableEle_Click().Switching_GeneralBasePage().Clicking_InstallationSec().InstallSec_Fields_Validations().installSecPage_FeildsArenotNull_validation().FieldEdit_Validation().SwitchingTo_GenBasePage().Clicking_NotesTab().SwitchingTo_GenBasePage().Clicking_InstallationSec().Validating_Edited_Fields();
  
        }
        public void Attachment_SecValidation(Object DataObj)
        {
            new XPOD_HomePage_Header(webDriver).Login_XPOD(DataObj);
            new XPOD_HomePage_Xpodlist(webDriver).Method_SelectViewValue(DataObj, "BVT_TestData", "Viewname").First_tableEle_Click().Switching_GeneralBasePage().Clicking_AttachementTab().AttachmentTab_Validation();

        }
        public void SystemView_Dropdown_Validation(Object DataObj)
        {
            new XPOD_HomePage_Header(webDriver).Login_XPOD(DataObj);
            new XPOD_HomePage_Xpodlist(webDriver).Method_SystemViewOptions_Validation(DataObj).Method_SelectViewValue(DataObj, "ViewList", "3").Method_validating_TableColumnValue("status","Canceled");
        }

        public void GenTabButton_XPOD_Validations(Object DataObj)
        {
            new XPOD_HomePage_Header(webDriver).Login_XPOD(DataObj);
            new XPOD_HomePage_Xpodlist(webDriver).Method_SelectViewValue(DataObj, "Test5867945", "View1").First_tableEle_Click().General_RIFeild_Validations();
            new XPOD_Genral_OI_Page(webDriver).General_OIFeild_Validations().GeneralTabButton_Validations_PendingSubmissionXPODs();
            new XPOD_HomePage_Header(webDriver).Method_Clicking_ValidationListButton();

            new XPOD_HomePage_Xpodlist(webDriver).Method_SelectViewValue(DataObj, "Test5867945", "View2").First_tableEle_Click().General_RIFeild_Validations();
            new XPOD_Genral_OI_Page(webDriver).General_OIFeild_Validations().GeneralTabButton_Validations_PendingSubmissionXPODs();
            new XPOD_HomePage_Header(webDriver).Method_Clicking_ValidationListButton();

            new XPOD_HomePage_Xpodlist(webDriver).Method_SelectViewValue(DataObj, "Test5867945", "View3").First_tableEle_Click().General_RIFeild_Validations();
            new XPOD_Genral_OI_Page(webDriver).General_OIFeild_Validations().GeneralTabButton_Validations_CanDenApprovedXPODs();
            new XPOD_HomePage_Header(webDriver).Method_Clicking_ValidationListButton();

            new XPOD_HomePage_Xpodlist(webDriver).Method_SelectViewValue(DataObj, "Test5867945", "View4").First_tableEle_Click().General_RIFeild_Validations();
            new XPOD_Genral_OI_Page(webDriver).General_OIFeild_Validations().GeneralTabButton_Validations_CanDenApprovedXPODs();
            new XPOD_HomePage_Header(webDriver).Method_Clicking_ValidationListButton();

            new XPOD_HomePage_Xpodlist(webDriver).Method_SelectViewValue(DataObj, "Test5867945", "View5").First_tableEle_Click().General_RIFeild_Validations();
            new XPOD_Genral_OI_Page(webDriver).General_OIFeild_Validations().GeneralTabButton_Validations_CanDenApprovedXPODs();
        }

        public void FullDbSearch_Validations(Object DataObj)
        {
            new XPOD_HomePage_Header(webDriver).Login_XPOD(DataObj).EnterSearchElement_FullDbSearch(DataObj);
            new XPOD_HomePage_Xpodlist(webDriver).searchfunction(DataObj);
        }
        public void CreateView_Validation(Object DataObj)
        {
            new XPOD_HomePage_Header(webDriver).Login_XPOD(DataObj);
            new XPOD_HomePage_Xpodlist(webDriver).Method_Clicking_AdvancedFind().click_CreateNewViewButton().CreateNewView_FieldValidations().Entering_NewView_Details().Click_CreateView().Method_SelectViewValue(DataObj, "Test5868036", "View").Method_validating_TableColumnValue("status", "Denied"); 
        }

        public void AdvancedFind_RetriveRecord_Validation(Object DataObj)
        {
            new XPOD_HomePage_Header(webDriver).Login_XPOD(DataObj);
            new XPOD_HomePage_Xpodlist(webDriver).Method_Clicking_AdvancedFind().click_CreateNewViewButton().Entering_NewView_Details().Click_Find().Method_SelectViewValue(DataObj, "Test5868036", "View").Method_validating_TableColumnValue("status", "Denied"); ;
        }
        public void AdvacnedFind_CloseFunction_validation(Object DataObj)
        {
            new XPOD_HomePage_Header(webDriver).Login_XPOD(DataObj);
            new XPOD_HomePage_Xpodlist(webDriver).Method_Clicking_AdvancedFind().AdvancedFind_SelectView(DataObj, "Test5867945", "View1").AdvanceFind_CloseFun();
        }
        public void SetDefaultView_validation(Object DataObj)
        {
            new XPOD_HomePage_Header(webDriver).Login_XPOD(DataObj);
            new XPOD_HomePage_Xpodlist(webDriver).Method_Clicking_AdvancedFind().Method_ComparingDefaultView_UsergivenValue(DataObj, "Test5867945", "View1");
            new XPOD_HomePage_Xpodlist(webDriver).Method_closebrowser();            
        }
        public void SetDefaultView_validation1(Object DataObj)
        {
            CommonMethods.launchBrowser();
            new XPOD_HomePage_Header(webDriver).Login_XPOD(DataObj);
            new XPOD_HomePage_Xpodlist(webDriver).Method_ViewDropdown_DefaultValueValidation(DataObj, "Test5867945", "View1");
        }

        public void validateAssign(Object DataObj)
        {
            
            new XPOD_HomePage_Header(webDriver).Login_XPOD(DataObj);
            new XPOD_HomePage_Xpodlist(webDriver).Method_SelectViewValue(DataObj, "Test5867945", "View1").First_tableEle_Click().General_RIFeild_Validations();
            new XPOD_AssignPage(webDriver).clickSECDropdown();
            new XPOD_AssignPage(webDriver).selectSEC(DataObj, "SECList", "1");
        }
    

        public void validateXPODList(Object DataObj)
        {

            new XPOD_HomePage_Header(webDriver).Login_XPOD(DataObj);
            new XPOD_HomePage_Xpodlist(webDriver).Method_SelectViewValue(DataObj, "Test5867945", "View1").First_tableEle_Click();
            Thread.Sleep(10000);
            new XPOD_ActivitesTab_Page(webDriver).validateList();
        }

        public void validateSaveAndNotify(Object DataObj)
        {
            
            new XPOD_HomePage_Header(webDriver).Login_XPOD(DataObj);
            new XPOD_HomePage_Xpodlist(webDriver).Method_SelectViewValue(DataObj, "Test5867945", "View1").First_tableEle_Click();
            new XPOD_ActivitesTab_Page(webDriver).saveNotify();


        }

        public void validateBtn(Object DataObj)
        {

            new XPOD_HomePage_Header(webDriver).Login_XPOD(DataObj);
            new XPOD_HomePage_Xpodlist(webDriver).Method_SelectViewValue(DataObj, "Test5867945", "View1").First_tableEle_Click();
            new XPOD_ValidatePage(webDriver).validateXPOD();
        }

        public void validateViewSub(Object DataObj)
        {

            new XPOD_HomePage_Header(webDriver).Login_XPOD(DataObj);
            new XPOD_HomePage_Xpodlist(webDriver).Method_SelectViewValue(DataObj, "Test5867945", "View1").First_tableEle_Click();
            new XPOD_ActivitesTab_Page(webDriver).viewSub();


        }




    }
}
