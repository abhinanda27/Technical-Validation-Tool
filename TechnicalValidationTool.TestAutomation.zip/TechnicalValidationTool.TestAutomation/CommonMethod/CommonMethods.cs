﻿using System;
using System.Collections.Generic;
using System.Text;
using OpenQA.Selenium;
using OpenQA.Selenium.Support.UI;
using Newtonsoft.Json.Linq;
using TechnicalValidationTool.TestAutomation;
using OpenQA.Selenium.Chrome;

namespace TechnicalValidationTool.TestAutomation.CommonMethod
{
    public static class CommonMethods
    {
        
        
        public static IWebDriver Page_Scolldown(IWebDriver driver)
        {
            IJavaScriptExecutor js = (IJavaScriptExecutor)driver;
            js.ExecuteScript("window.scrollBy(0,1000)");
            return driver;
        }
        //Webdriver Wait
        public static IWebDriver WebdriverWait_ElementClickable(IWebDriver driver, IWebElement Element)
        {
            WebDriverWait wait = new WebDriverWait(driver, TimeSpan.FromSeconds(30));
            wait.Until(ExpectedConditions.ElementToBeClickable(Element));
            return driver;
        }
        public static IWebDriver Page_ScrollUp(IWebDriver driver)
        {
            IJavaScriptExecutor js = (IJavaScriptExecutor)driver;
            js.ExecuteScript("window.scrollBy(0,-1000)");
            return driver;
        }
        public static IWebDriver WebdriverWait_ElementToBeSelected(IWebDriver driver, IWebElement Element)
        {
            WebDriverWait wait = new WebDriverWait(driver, TimeSpan.FromSeconds(30));
            wait.Until(ExpectedConditions.ElementToBeSelected(Element));
            return driver;
        }
        public static void launchBrowser()
        {
            IWebDriver driver = new ChromeDriver();
        }


    }
    }
