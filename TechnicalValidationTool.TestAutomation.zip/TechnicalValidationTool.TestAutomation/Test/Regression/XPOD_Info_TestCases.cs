﻿using System;
using System.Collections.Generic;
using System.Text;
using Xunit;
using OpenQA.Selenium;
using TechnicalValidationTool.TestAutomation.Base;
using TechnicalValidationTool.TestAutomation.Workflow;

namespace TechnicalValidationTool.TestAutomation.Test.P1_TestFiles
{
    public class XPOD_Info_TestCases:TestBase

    {
        [Theory]
        [Trait("Category", "Regression_TestCases")]
        [JsonFileData("Data\\GE1\\BVT_TestData.json")]
        public void Installation_Section_Validations(Object DataObj)
        {
            new Workflows(webDriverTest).Installation_SecValidation(DataObj);
        }

        [Theory]
        [Trait("Category", "Regression_TestCases")]
        [JsonFileData("Data\\GE1\\BVT_TestData.json")]
        public void Attachment_Section_Validations(Object DataObj)
        {
            new Workflows(webDriverTest).Attachment_SecValidation(DataObj);
        }
        [Theory]
        [Trait("Category", "Regression_TestCases")]
        [JsonFileData("Data\\GE1\\BVT_TestData.json")]
        public void SystemViews_Dropdown_Validations(Object DataObj)
        {
            new Workflows(webDriverTest).SystemView_Dropdown_Validation(DataObj);
        }

        [Theory]
        [Trait("Category", "Regression_TestCases")]
        [JsonFileData("Data\\GE1\\BVT_TestData.json")]
        public void GenTabButton_XPOD_Validations(Object DataObj)
        {
            new Workflows(webDriverTest).GenTabButton_XPOD_Validations(DataObj);
        }

        [Theory]
        [Trait("Category", "Regression_TestCases")]
        [JsonFileData("Data\\GE1\\BVT_TestData.json")]
        public void FullDbSearch_Validation(Object DataObj)
        {
            new Workflows(webDriverTest).FullDbSearch_Validations(DataObj);
        }

        [Theory]
        [Trait("Category", "Regression_TestCases")]
        [JsonFileData("Data\\GE1\\BVT_TestData.json")]
        public void CreateView_Validation(Object DataObj)
        {
            new Workflows(webDriverTest).CreateView_Validation(DataObj);
        }
        [Theory]
        [Trait("Category", "Regression_TestCases")]
        [JsonFileData("Data\\GE1\\BVT_TestData.json")]
        public void RetriveRecrod_AdvancedFind_Validation(Object DataObj)
        {
            new Workflows(webDriverTest).AdvancedFind_RetriveRecord_Validation(DataObj);
        }
        [Theory]
        [Trait("Category", "Regression_TestCases")]
        [JsonFileData("Data\\GE1\\BVT_TestData.json")]
        public void AdvancedFind_closefunction_Validation(Object DataObj)
        {
            new Workflows(webDriverTest).AdvacnedFind_CloseFunction_validation(DataObj);
        }

        [Theory]
        [Trait("Category", "Regression_TestCases")]
        [JsonFileData("Data\\GE1\\BVT_TestData.json")]
        public void SetDefaultView_Validation(Object DataObj)
        {
            new Workflows(webDriverTest).SetDefaultView_validation(DataObj);
            new Workflows(webDriverTest).SetDefaultView_validation1(DataObj);
        }

        [Theory]
        [Trait("Category", "Regression_TestCases")]
        [JsonFileData("Data\\GE1\\BVT_TestData.json")]
        public void assignValidation(Object DataObj)
        {
            new Workflows(webDriverTest).validateAssign(DataObj);
           
        }

        [Theory]
        [Trait("Category", "Regression_TestCases")]
        [JsonFileData("Data\\GE1\\BVT_TestData.json")]
        ////Test Case 5841136--author Abhi
        public void validationList(Object DataObj)
        {
            new Workflows(webDriverTest).validateXPODList(DataObj);

        }

        [Theory]
        [Trait("Category", "Regression_TestCases")]
        [JsonFileData("Data\\GE1\\BVT_TestData.json")]
        ////Test Case 5841136--author Abhi
        public void saveAndNotify(Object DataObj)
        {
            new Workflows(webDriverTest).validateSaveAndNotify(DataObj);

        }


        [Theory]
        [Trait("Category", "Regression_TestCases")]
        [JsonFileData("Data\\GE1\\BVT_TestData.json")]
        ////Test Case 5841136--author Abhi
        public void validateBtn(Object DataObj)
        {
            new Workflows(webDriverTest).validateBtn(DataObj);

        }

        [Theory]
        [Trait("Category", "Regression_TestCases")]
        [JsonFileData("Data\\GE1\\BVT_TestData.json")]
        ////Test Case 5841136--author Abhi
        public void viewSubmission(Object DataObj)
        {
            new Workflows(webDriverTest).validateViewSub(DataObj);

        }
    }
}
