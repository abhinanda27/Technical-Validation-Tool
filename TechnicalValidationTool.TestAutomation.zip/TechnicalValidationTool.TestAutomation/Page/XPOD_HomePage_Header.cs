﻿using System;
using System.Collections.Generic;
using System.Text;
using System.Threading;
using OpenQA.Selenium;
using OpenQA.Selenium.Chrome;
using OpenQA.Selenium.Firefox;
using OpenQA.Selenium.Support.UI;
using TechnicalValidationTool.TestAutomation.Base;
using TechnicalValidationTool.TestAutomation.CommonMethod;
using TechnicalValidationTool.TestAutomation.Helper;
using Xunit;

namespace TechnicalValidationTool.TestAutomation.Page
{
    public class XPOD_HomePage_Header:PageBase
    {
        public IWebDriver driver;
        
        public XPOD_HomePage_Header(IWebDriver driverinstance)
        {
            driver = driverinstance;
        }
        public IWebElement txt_page_header()
        {
            return driver.FindElement(By.XPath("//font[text()='Technical Validation']"));
        }
        
        public IWebElement DellLogo()
        {
            return driver.FindElement(By.ClassName("logo"));
        }
        public IWebElement Txt_Username()
        {
            return driver.FindElement(By.XPath("//div[@class='welcomeMessage ng-star-inserted'][contains(text(),'Ravikumar Nemani')]"));
        }
        public IWebElement Txt_TechValidSub()
        {
            return driver.FindElement(By.XPath("//div[@class='welcomeMessage ng-star-inserted'][contains(text(),'Ravikumar Nemani')]"));
        }
        public IWebElement TextBox_Fulldb_Search()
        {
            return driver.FindElement(By.Id("filterTextGlobal"));
        }
        public IWebElement FullDbSearch_SearchBtn()
        {
            return driver.FindElement(By.XPath("//input[@id='filterTextGlobal']//following::i[1]"));
        }
        public IWebElement Btn_ValidationList()
        {
            return driver.FindElement(By.Id("btnBack"));
        }
       
       

        //Actons
        /// <summary>
        /// Loading the Technical Validation Page and validating the header text is displayed.
        /// Passing URL and details through the object from the JSON file
        /// </summary>
        /// <param name="value"></param>
        /// <returns></returns>
        public XPOD_HomePage_Header Login_XPOD(Object value)
        {
            var data = GetDataAsJsonObject.DataReaderJobject(value, "BVT_TestData");
            var url = data["URL"];
            driver.Manage().Window.Maximize();
            driver.Navigate().GoToUrl(url.ToString());
            Thread.Sleep(10000);
            CommonMethods.WebdriverWait_ElementClickable(driver, txt_page_header());
            Assert.True(txt_page_header().Displayed);            
            return new XPOD_HomePage_Header(driver); 
        }
  
        /// <summary>
        /// Validating different attributes in the Home Page
        /// Dell Logo,Welcome notes and user name,Technical Validation Submission text validations
        /// full db search textbox is enabled validations
        /// </summary>
        /// <returns></returns>
        public XPOD_HomePage_Header Field_Validations()
        {
            Assert.True(DellLogo().Displayed);
            Assert.True(Txt_Username().Displayed);
            Assert.True(Txt_TechValidSub().Displayed);
            Assert.True(TextBox_Fulldb_Search().Enabled);
            return new XPOD_HomePage_Header(driver);
        }
        /// <summary>
        /// Method to click on the validation list button
        /// </summary>
        /// <returns></returns>
        public XPOD_HomePage_Header Method_Clicking_ValidationListButton()
        {
            Btn_ValidationList().Click();

            return new XPOD_HomePage_Header(driver);
        }
       
        public XPOD_HomePage_Header EnterSearchElement_FullDbSearch(Object DataObj)
        {
            var data = GetDataAsJsonObject.DataReaderJobject(DataObj, "BVT_TestData");
            var searchval = data["Searchvalue"];
            TextBox_Fulldb_Search().SendKeys(searchval.ToString());
            FullDbSearch_SearchBtn().Click();
            return new XPOD_HomePage_Header(driver);
        }
        public XPOD_HomePage_Header launchBrowser()
        {
            PageBase page = new PageBase();
            return new XPOD_HomePage_Header(driver);
        }
        

      
    }
}
