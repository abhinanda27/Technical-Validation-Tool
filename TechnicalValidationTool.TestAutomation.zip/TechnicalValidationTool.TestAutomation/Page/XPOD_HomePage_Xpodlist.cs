﻿using System;
using System.Collections.Generic;
using System.Text;
using System.Threading;
using OpenQA.Selenium;
using OpenQA.Selenium.Firefox;
using OpenQA.Selenium.Support.UI;
using TechnicalValidationTool.TestAutomation.Base;
using TechnicalValidationTool.TestAutomation.CommonMethod;
using TechnicalValidationTool.TestAutomation.Helper;
using Xunit;

namespace TechnicalValidationTool.TestAutomation.Page
{
    public class XPOD_HomePage_Xpodlist : PageBase
    {
        public IWebDriver driver;
        String DefaultViewName;


        public XPOD_HomePage_Xpodlist(IWebDriver driverinstance)
        {
            driver = driverinstance;
        }

        public int NoOfRows()
        {
            return driver.FindElements(By.XPath("//mat-table[@id='validationList']//mat-row")).Count;
        }
        public IWebElement Table_FirstEle()
        {
            return driver.FindElement(By.XPath("//mat-table[@id='validationList']//mat-row[1]//mat-cell[1]"));
        }
        
        public IWebElement dd_Pagecount10()
        {
            return driver.FindElement(By.XPath("//div[@class='mat-form-field-infix']"));
        }
        public IWebElement dd_Pagecount5()
        {
            return driver.FindElement(By.XPath("//mat-option[@id='mat-option-0']//span[@class='mat-option-text'][contains(text(),'5')]"));
        }
        public IWebElement dd_PageCount15()
        {
            return driver.FindElement(By.XPath("//span[@class='mat-option-text'][contains(text(),'15')]"));
        }
        public IWebElement dd_PagecountArrow()
        {
            return driver.FindElement(By.XPath("//div[@class='mat-select-arrow']"));
        }
        public IWebElement dd_views()
        {
            return driver.FindElement(By.XPath("//select[@id='viewSelect']"));
        }
        public IWebElement btn_AdvancedFind()
        {
            return driver.FindElement(By.Id("advanceFindIcon"));
        }
        public IWebElement TextBox_SeachEle()
        {
            return driver.FindElement(By.Id("filterText"));
        }
        public IList<IWebElement> TableRows()
        {
           IList<IWebElement> HeaderRows = driver.FindElements(By.XPath("//mat-header-row//mat-header-cell"));
            return HeaderRows;
        }
        public IWebElement Status_Column()
        {
            return driver.FindElement(By.XPath("//mat-header-cell//strong[contains(text(),' Status ')]"));
        }
        

        //Actions
        /// <summary>
        /// Method is to check search an element in the XPOD list and return whether its present or not
        /// 
        /// </summary>
        /// <param name="DataObj"></param>
        /// <returns></returns>
        public XPOD_HomePage_Xpodlist searchfunction(Object DataObj)
        {
            var data = GetDataAsJsonObject.DataReaderJobject(DataObj, "BVT_TestData");
            var SearchVal = data["Searchvalue"];

            if (NoOfRows()==0)
            {
                Console.WriteLine("Search element is not present");
            }
            else
            {
                for (int i = 1; i <= NoOfRows(); i++)
                {
                    int counter = 0;

                    IList<IWebElement> rowele = driver.FindElements(By.XPath("//mat-table[@id='validationList']//mat-row[" + i + "]/mat-cell"));

                    foreach (var Ele in rowele)
                    {

                        if (Ele.Text.Equals(SearchVal.ToString()) || Ele.Text.Contains(SearchVal.ToString()))
                        {

                            counter = counter + 1;

                        }
                    }
                    Assert.NotEqual(0, counter);
                    

                }
            }

            return new XPOD_HomePage_Xpodlist(driver);
        }
        /// <summary>
        /// Click on the first element request number(first row) from the XPOD list table visible
        /// </summary>
        /// <returns>This will navigate to General Page, hence returning General RI Page</returns>
        public XPOD_General_RI_Page First_tableEle_Click()
        {
            CommonMethods.WebdriverWait_ElementClickable(driver, Table_FirstEle());
            Table_FirstEle().Click();
            //String RequestNo = Table_FirstEle().Text;

            return new XPOD_General_RI_Page(driver);
        }

        /// <summary>
        /// Validating the pagingation default value and the values 5,10 and 15.
        /// </summary>
        /// <returns>returning the same page</returns>
        public XPOD_HomePage_Xpodlist Pagination_validation()
        {
            Assert.Equal("10", dd_Pagecount10().Text);//default value check

            CommonMethods.WebdriverWait_ElementClickable(driver, dd_PagecountArrow());

            driver.FindElement(By.XPath("//div[@class='mat-select-arrow']")).Click();

            CommonMethods.WebdriverWait_ElementClickable(driver, dd_Pagecount5());
            Assert.Equal("5", dd_Pagecount5().Text);
            Assert.Equal("10", dd_Pagecount10().Text);
            Assert.Equal("15", dd_PageCount15().Text);
            return new XPOD_HomePage_Xpodlist(driver);

        }
        /// <summary>
        /// Method to scroll down the page till end
        /// </summary>
        /// <returns></returns>
        public XPOD_HomePage_Xpodlist ScrollTillEnd()
        {
            CommonMethods.Page_Scolldown(driver);
            return new XPOD_HomePage_Xpodlist(driver);
        }
   
        /// <summary>
        ///Method to enter the search value in the search text box.
        ///Search value have passed as object JSON Objects
        /// </summary>
        /// <param name="DataObj"></param>
        /// <returns></returns>
        public XPOD_HomePage_Xpodlist Method_Enter_SearchElement(Object DataObj)
        {
            var data = GetDataAsJsonObject.DataReaderJobject(DataObj, "BVT_TestData");
            var SearchVal = data["Searchvalue"];
            TextBox_SeachEle().SendKeys(SearchVal.ToString());//sending the search value to the search textbox
            return new XPOD_HomePage_Xpodlist(driver);
        }
        /// <summary>
        /// To validate the Search box and Advanced find button is enabled
        /// </summary>
        /// <returns></returns>
        public XPOD_HomePage_Xpodlist Method_FieldValidations()
        {
            Assert.True(TextBox_SeachEle().Enabled);//element searchbox is enables or not
            Assert.True(btn_AdvancedFind().Displayed);//advanced find button validation
            return new XPOD_HomePage_Xpodlist(driver);
        }

        /// <summary>
        /// this method is to compare the dropdown view values and the list of mandatory values 
        /// given in the JSON file
        /// </summary>
        /// <param name="DataObj"></param>
        /// <returns></returns>
        public XPOD_HomePage_Xpodlist Method_SystemViewOptions_Validation(Object DataObj)
        {
            var data = GetDataAsJsonObject.DataReaderJobject(DataObj, "ViewList");
            int NumberofRec = 11;//Convert.ToInt16( data["NoRec"]);
            
            CommonMethods.WebdriverWait_ElementClickable(driver, dd_views());
            SelectElement options = new SelectElement(dd_views());
            IList<IWebElement> ViewOptions = options.Options;

            for (int i = 1; i <= NumberofRec; i++)
            {
                String s = i.ToString();
                int counter = 0;
                foreach (var Ele in ViewOptions)
                {
                  if((data[s].ToString()).Equals(Ele.Text))
                    {
                      counter = counter + 1;
                    }
                }
                Assert.NotEqual(0, counter);                
            }
                
            return new XPOD_HomePage_Xpodlist(driver);
        }

        public XPOD_HomePage_Xpodlist SystemView_SelectionValidations(Object DataObj)
        {
            var data = GetDataAsJsonObject.DataReaderJobject(DataObj, "ViewList");
            int NumberofRec = 2;
            CommonMethods.WebdriverWait_ElementClickable(driver, dd_views());
            SelectElement options = new SelectElement(dd_views());
            for (int i = 0; i <= NumberofRec; i++)
            {
                options.SelectByText((data[i.ToString()]).ToString());

                if(i==1)
                {
                    Status_Column();
                }


            }
            return new XPOD_HomePage_Xpodlist(driver);

        }
        /// <summary>
        /// Selecting the view value from the dropdown.
        /// values are passed through parameters.
        /// </summary>
        /// <param name="DataObj"></param>
        /// <param name="TestName"></param>
        /// <param name="TestValue"></param>
        /// <returns></returns>   
        
        public XPOD_HomePage_Xpodlist  Method_SelectViewValue(Object DataObj,String TestName,String TestValue)
        {
            var data = GetDataAsJsonObject.DataReaderJobject(DataObj, TestName);
            var viewName = data[TestValue];
            CommonMethods.WebdriverWait_ElementClickable(driver, dd_views());
            Thread.Sleep(5000);
            SelectElement options = new SelectElement(dd_views());
            options.SelectByText(viewName.ToString());
            Thread.Sleep(5000);
            return new XPOD_HomePage_Xpodlist(driver);
        }
        /// <summary>
        /// This method is to click on the advanced find button
        /// </summary>
        /// <returns></returns>
        public AdvancedFind_Page Method_Clicking_AdvancedFind()
        {
            btn_AdvancedFind().Click();
            
            return new AdvancedFind_Page(driver);
        }
        /// <summary>
        /// This method is to compare the given Column name and the column value
        /// </summary>
        /// <param name="ColumnName"></param>
        /// <param name="value"></param>
        public void Method_validating_TableColumnValue(String ColumnName,String value)
        {
            IList<IWebElement> ColumnValues = driver.FindElements(By.XPath("//mat-cell[@class='mat-cell cdk-column-" + ColumnName + " mat-column-" + ColumnName + " ng-star-inserted']"));
            foreach(var Ele in ColumnValues)
            {
                Assert.Contains(value, Ele.Text);
            }
        }
        /// <summary>
        /// This method is to close the browser
        /// </summary>
        public void Method_closebrowser()
        {
            driver.Quit();
        }
        /// <summary>
        /// This method is to compare the passed view name and the default view name
        /// </summary>
        /// <param name="DataObj"></param>
        /// <param name="TestName"></param>
        /// <param name="TestValue"></param>
        public void Method_ViewDropdown_DefaultValueValidation(Object DataObj, String TestName, String TestValue)
        {
            var data = GetDataAsJsonObject.DataReaderJobject(DataObj, TestName);
            var viewname = data[TestValue];
            String str = dd_views().Text.Trim();
            Assert.Equal(str, viewname.ToString());
        }
        
    
    }
}

