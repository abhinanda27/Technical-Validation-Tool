﻿using System;
using System.Collections.Generic;
using System.Text;
using Xunit;
using OpenQA.Selenium;
using TechnicalValidationTool.TestAutomation.Workflow;
using TechnicalValidationTool.TestAutomation.CommonMethod;

namespace TechnicalValidationTool.TestAutomation.Page
{
    public class XPOD_InstallationSec_Page
    {
        public IWebDriver driver;

        public XPOD_InstallationSec_Page(IWebDriver driverinstance)
        {
            driver = driverinstance;
        }

        public IWebElement Lbl_Addressline1()
        {
            return driver.FindElement(By.XPath("//label[contains(text(),'Address Line 1')]"));
        }
        public IWebElement Txtbox_Addressline1()
        {
            return driver.FindElement(By.XPath("//label[contains(text(),'Address Line 1')]//following::input[1]"));
        }
        public IWebElement Lbl_Addressline2()
        {
            return driver.FindElement(By.XPath("//label[contains(text(),'Address Line 2')]"));
        }
        public IWebElement Txtbox_Addressline2()
        {
            return driver.FindElement(By.XPath("//label[contains(text(),'Address Line 2')]//following::input[1]"));
        }
        public IWebElement Lbl_City()
        {
            return driver.FindElement(By.XPath("//label[contains(text(),'City')]"));
        }
        public IWebElement Txtbox_City()
        {
            return driver.FindElement(By.XPath("//label[contains(text(),'City')]//following::input[1]"));
        }
        public IWebElement Lbl_State()
        {
            return driver.FindElement(By.XPath("//label[contains(text(),'State / Province')]"));
        }
        public IWebElement Txtbox_State()
        {
            return driver.FindElement(By.XPath("//label[contains(text(),'State / Province')]//following::input[1]"));
        }
        public IWebElement Lbl_Country()
        {
            return driver.FindElement(By.XPath("//label[contains(text(),'Country')]"));
        }
        public IWebElement Txtbox_Country()
        {
            return driver.FindElement(By.XPath("//label[contains(text(),'Country')]//following::input[1]"));
        }
        public IWebElement Lbl_ZipCode()
        {
            return driver.FindElement(By.XPath("//label[contains(text(),'Zip Code')]"));
        }
        public IWebElement Txtbox_ZipCode()
        {
            return driver.FindElement(By.XPath("//label[contains(text(),'Zip Code')]//following::input[1]"));
        }
        public IWebElement Btn_SaveInstallInfo()
        {
            return driver.FindElement(By.XPath("//button[@type='submit']"));
        }

        //methods
        /// <summary>
        /// This method is to validate the fields populated in the intallation section Tab
        /// </summary>
        /// <returns></returns>
        public XPOD_InstallationSec_Page InstallSec_Fields_Validations()
        {
            CommonMethods.WebdriverWait_ElementClickable(driver, Lbl_Addressline1());
            Assert.True(Lbl_Addressline1().Displayed);
            Assert.True(Lbl_Addressline2().Displayed);
            Assert.True(Lbl_City().Displayed);
            Assert.True(Lbl_State().Displayed);
            Assert.True(Lbl_Country().Displayed);
            Assert.True(Lbl_ZipCode().Displayed);
            Assert.True(Btn_SaveInstallInfo().Enabled);

            return new XPOD_InstallationSec_Page(driver);
        }
        /// <summary>
        /// This method is to validate the mandatory fields in Intallation sections are not null
        /// </summary>
        /// <returns></returns>
        public XPOD_InstallationSec_Page installSecPage_FeildsArenotNull_validation()
        {
            //method to validate the textbox are having some value. not blank
            Assert.NotNull(Txtbox_Addressline1().Text);
            Assert.NotNull(Txtbox_Addressline2().Text);
            Assert.NotNull(Txtbox_City().Text);
            Assert.NotNull(Txtbox_State().Text);
            Assert.NotNull(Txtbox_Country().Text);
            Assert.NotNull(Txtbox_ZipCode().Text);
            Assert.True(Btn_SaveInstallInfo().Enabled);
        
            return new XPOD_InstallationSec_Page(driver);
        }   
        /// <summary>
        /// This method is to Edit the existing fields and save
        /// </summary>
        /// <returns></returns>
        public XPOD_InstallationSec_Page FieldEdit_Validation()
        {
            Txtbox_Addressline1().Clear();
            Txtbox_Addressline1().SendKeys("TestAddress1");
            Txtbox_Addressline2().Clear();
            Txtbox_Addressline2().SendKeys("TestAddress2");
            CommonMethods.WebdriverWait_ElementClickable(driver, Btn_SaveInstallInfo());
            CommonMethods.Page_Scolldown(driver);
            Btn_SaveInstallInfo().Click();
            //CommonMethods.Page_ScrollUp(driver);

            return new XPOD_InstallationSec_Page(driver);
        }
        public XPOD_InstallationSec_Page Validating_Edited_Fields()
        {
            Assert.Equal("TestAddress1", Txtbox_Addressline1().Text);
            Assert.Equal("TestAddress2", Txtbox_Addressline2().Text);

            return new XPOD_InstallationSec_Page(driver);
        }
        
        public XPOD_General_StaticEle_Page SwitchingTo_GenBasePage()
        {
            return new XPOD_General_StaticEle_Page(driver);
        }
    }
}
