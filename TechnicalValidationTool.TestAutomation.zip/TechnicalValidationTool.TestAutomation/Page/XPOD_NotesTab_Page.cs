﻿using System;
using System.Collections.Generic;
using System.Text;
using System.Threading;
using OpenQA.Selenium;
using OpenQA.Selenium.Firefox;
using OpenQA.Selenium.Support.UI;
using TechnicalValidationTool.TestAutomation.Base;
using TechnicalValidationTool.TestAutomation.CommonMethod;
using TechnicalValidationTool.TestAutomation.Helper;
using Xunit;
namespace TechnicalValidationTool.TestAutomation.Page
{
    public class XPOD_NotesTab_Page:PageBase
    {
        public IWebDriver driver;
        
        public XPOD_NotesTab_Page(IWebDriver driverinstance)
        {
            driver = driverinstance;
        }

        public IWebElement TxtArea_AddNote()
        {
            return driver.FindElement(By.XPath("//label[@class='col-form-label-sm']//following::textarea"));
        }
        public IWebElement Btn_CreateNote()
        {
            return driver.FindElement(By.Id("btnCreateNote"));
        }
        public IWebElement Notes_table()
        {
            return driver.FindElement(By.XPath("//mat-table[@class='mat-elevation-z1 mat-table']"));
        }
        public IWebElement FirstCell_NotesTable()
        {
            return driver.FindElement(By.XPath("//mat-table//mat-row[1]//mat-cell[1]"));
        }

        //Actons
        public XPOD_NotesTab_Page Creating_Notes(Object DataObj)
        {
            var data = GetDataAsJsonObject.DataReaderJobject(DataObj, "BVT_TestData");
            var Notes = data["Notes"];
            TxtArea_AddNote().SendKeys(Notes.ToString());
            Btn_CreateNote().Click();
            Thread.Sleep(10000);
            return new XPOD_NotesTab_Page(driver);
        }
        public XPOD_NotesTab_Page CreatedNote_Validation(Object DataObj)
        {
            var data = GetDataAsJsonObject.DataReaderJobject(DataObj, "BVT_TestData");
            var Notes = data["Notes"];
            CommonMethods.WebdriverWait_ElementClickable(driver, Notes_table());
            Assert.True(Notes_table().Displayed);
            Assert.Equal(Notes.ToString(), FirstCell_NotesTable().Text);
            return new XPOD_NotesTab_Page(driver);
        }
        public XPOD_General_StaticEle_Page SwitchingTo_GenBasePage()
        {
            return new XPOD_General_StaticEle_Page(driver);
        }
    }
}
