﻿using System;
using System.Collections.Generic;
using System.Text;
using System.Threading;
using OpenQA.Selenium;
using OpenQA.Selenium.Firefox;
using OpenQA.Selenium.Support.UI;
using TechnicalValidationTool.TestAutomation.Base;
using TechnicalValidationTool.TestAutomation.CommonMethod;
using TechnicalValidationTool.TestAutomation.Helper;
using Xunit;
using System.Linq;
namespace TechnicalValidationTool.TestAutomation.Page
{
    public class XPOD_AssignPage : PageBase
    {
        public IWebDriver driver;

        public XPOD_AssignPage(IWebDriver driverinstance)
        {
            driver = driverinstance;
        }

        public IWebElement assignDropdown()
        {

           return driver.FindElement(By.Id("ddlVc"));
            

        }

        public IWebElement assignBtn()
        {
            return driver.FindElement(By.Id("btnAssign"));


        }

        public IWebElement closeBtn()
        {
            return driver.FindElement(By.ClassName("buttonMuseo"));


        }

        //Actons


        public XPOD_AssignPage clickSECDropdown()
        {
            new XPOD_AssignPage(driver).ScrollTillEnd();
            Thread.Sleep(10000);
            new XPOD_Genral_OI_Page(driver).Btn_Assign().Click();
            Thread.Sleep(20000);
            driver.SwitchTo().Window(driver.WindowHandles.Last()).Manage().Window.Maximize();
            Thread.Sleep(10000);
            Assert.True(assignDropdown().Enabled);
            return new XPOD_AssignPage(driver);
        }

        public XPOD_AssignPage selectSEC(Object DataObj, String TestName, String TestValue)
        {
            var data = GetDataAsJsonObject.DataReaderJobject(DataObj, TestName);
            var names = data[TestValue];
            Thread.Sleep(2000);
            SelectElement sec = new SelectElement(assignDropdown());
            sec.SelectByText(names.ToString());
            Thread.Sleep(10000);
            assignBtn().Click();
            Thread.Sleep(10000);
            Assert.True(closeBtn().Enabled);
            return new XPOD_AssignPage(driver);
        }


        /// <summary>
        /// Method to scroll down the page till end
        /// </summary>
        /// <returns></returns>
        public XPOD_AssignPage ScrollTillEnd()
        {
            CommonMethods.Page_Scolldown(driver);
            return new XPOD_AssignPage(driver);
        }
    }
}
