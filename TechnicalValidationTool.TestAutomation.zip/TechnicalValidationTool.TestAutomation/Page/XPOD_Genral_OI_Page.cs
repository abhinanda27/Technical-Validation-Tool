﻿using System;
using System.Collections.Generic;
using System.Text;
using System.Threading;
using OpenQA.Selenium;
using OpenQA.Selenium.Firefox;
using OpenQA.Selenium.Support.UI;
using TechnicalValidationTool.TestAutomation.Base;
using Xunit;


namespace TechnicalValidationTool.TestAutomation.Page
{
    class XPOD_Genral_OI_Page:PageBase
    {
        public IWebDriver driver;

        public XPOD_Genral_OI_Page(IWebDriver driverinstance)
        {
            driver = driverinstance;
        }

        //Webelements
        public IWebElement Lbl_DealID()
        {
            return driver.FindElement(By.XPath("//label[contains(text(),'SFDC Deal Id')]"));
        }
        public IWebElement Txtbox_DealID()
        {
            return driver.FindElement(By.XPath("//label[contains(text(),'SFDC Deal Id')]//following::input[1]"));
        }

        public IWebElement Lbl_CustomerName()
        {
            return driver.FindElement(By.XPath("//label[contains(text(),'Customer Name')]"));
        }
        public IWebElement Txtbox_CustomerName()
        {
            return driver.FindElement(By.XPath("//label[contains(text(),'Customer Name')]//following::input[1]"));
        }
        public IWebElement Lbl_CustAffID()
        {
            return driver.FindElement(By.XPath("//label[contains(text(),'Customer Affinity Id')]"));
        }
        public IWebElement Txtbox_CustAffID()
        {
            return driver.FindElement(By.XPath("//label[contains(text(),'Customer Affinity Id')]//following::input[1]"));
        }
        public IWebElement Lbl_OpertunityName()
        {
           return driver.FindElement(By.XPath("//label[contains(text(),'Opportunity Name')]"));
        }
        public IWebElement Txtbox_OpertunityName()
        {
            return driver.FindElement(By.XPath("//label[contains(text(),'Opportunity Name')]//following::input[1]"));
        }
        public IWebElement Lbl_PartnerName()
        {
            return driver.FindElement(By.XPath("//label[contains(text(),'Partner Name')]"));
        }
        public IWebElement Txtbox_PartnerName()
        {
            return driver.FindElement(By.XPath("//label[contains(text(),'Partner Name')]//following::input[1]"));
        }
        public IWebElement Lbl_PartAffID()
        {
            return driver.FindElement(By.XPath("//label[contains(text(),'Partner Affinity Id')]"));
        }
        public IWebElement Txtbox_PartAffID()
        {
            return driver.FindElement(By.XPath("//label[contains(text(),'Partner Affinity Id')]//following::input[1]"));
        }
        public IWebElement Lbl_Opertunity_Header()
        {
            return driver.FindElement(By.XPath("//strong[contains(text(),'Deal/Opportunity Information')]"));
        }
        public IWebElement Btn_Save()
        {
            return driver.FindElement(By.Id("btnSave"));
        }
        public IWebElement Btn_SaveAndNotify()
        {
            return driver.FindElement(By.Id("btnSaveNotify"));
        }
        public IWebElement Btn_Assign()
        {
            return driver.FindElement(By.Id("btnAssign"));
        }
        public IWebElement Btn_Validate()
        {
            return driver.FindElement(By.Id("btnValidate"));
        }
        public IWebElement Btn_ViewSubmission()
        {
            return driver.FindElement(By.Id("btnViewSubmission"));
        }

        public IWebElement btnValidationList()
        {
            return driver.FindElement(By.Id("btnBack"));
        }


        //Methods-actions
        /// <summary>
        /// This General_OIFeild_Validations method is to validate the Deal/Opertunity information
        /// populated in the General Opertunity information sections.
        /// </summary>
        /// <returns></returns>
        public XPOD_Genral_OI_Page General_OIFeild_Validations()
        {
            Assert.True(Lbl_Opertunity_Header().Displayed);
            Assert.True(Lbl_DealID().Displayed);
            Assert.True(Txtbox_DealID().Enabled);
            Assert.True(Lbl_CustomerName().Displayed);
            Assert.False(Txtbox_CustomerName().Enabled);
            Assert.True(Lbl_CustAffID().Displayed);
            Assert.False(Txtbox_CustAffID().Enabled);
            Assert.True(Lbl_OpertunityName().Displayed);
            Assert.False(Txtbox_OpertunityName().Enabled);
            Assert.True(Lbl_PartnerName().Displayed);
            Assert.False(Txtbox_PartnerName().Enabled);
            Assert.True(Lbl_PartAffID().Displayed);
            Assert.False(Txtbox_PartAffID().Enabled);

            return new XPOD_Genral_OI_Page(driver);
        }
        public XPOD_Genral_OI_Page GeneralTabButton_Validations_PendingSubmissionXPODs()
        {
            Assert.True(Btn_Save().Enabled);
            Assert.True(Btn_Assign().Enabled);
            Assert.True(Btn_SaveAndNotify().Enabled);
            Assert.True(Btn_Validate().Enabled);
            Assert.True(Btn_ViewSubmission().Enabled);
            return new XPOD_Genral_OI_Page(driver);
        }
        public XPOD_Genral_OI_Page GeneralTabButton_Validations_CanDenApprovedXPODs()
        {
            Assert.False(Btn_Save().Enabled);
            Assert.False(Btn_Assign().Enabled);
            Assert.False(Btn_SaveAndNotify().Enabled);
            Assert.False(Btn_Validate().Enabled);
            Assert.True(Btn_ViewSubmission().Enabled);
            return new XPOD_Genral_OI_Page(driver);
        }
    }
}
