﻿using System;
using System.Collections.Generic;
using System.Text;
using System.Threading;
using OpenQA.Selenium;
using OpenQA.Selenium.Firefox;
using OpenQA.Selenium.Support.UI;
using TechnicalValidationTool.TestAutomation.Base;
using TechnicalValidationTool.TestAutomation.CommonMethod;
using Xunit;
using System.Linq;

namespace TechnicalValidationTool.TestAutomation.Page
{
    public class XPOD_ActivitesTab_Page:PageBase
    {
        public IWebDriver driver;

        public XPOD_ActivitesTab_Page(IWebDriver driverinstance)
        {
            driver = driverinstance;
        }

        public IWebElement Table_Activites()
        {
            return driver.FindElement(By.XPath("//mat-table[@class='mat-elevation-z1 mat-table']"));
        }
        public int Rowcount_ActivityTable()
        {
            return driver.FindElements(By.XPath("//mat-table[@class='mat-elevation-z1 mat-table']//mat-row")).Count;
        }



        public XPOD_ActivitesTab_Page Activity_Table_Generation_Validation()
        {
            Thread.Sleep(5000);
            CommonMethods.WebdriverWait_ElementClickable(driver, Table_Activites());
            Assert.True(Table_Activites().Displayed);
            Assert.NotEqual(0, Rowcount_ActivityTable());

            return new XPOD_ActivitesTab_Page(driver);
        }

        public XPOD_ActivitesTab_Page validateList()
        {

            new XPOD_Genral_OI_Page(driver).btnValidationList().Click();
            Thread.Sleep(10000);
            Assert.True(new XPOD_HomePage_Xpodlist(driver).btn_AdvancedFind().Enabled);
            Assert.True(new XPOD_HomePage_Header(driver).TextBox_Fulldb_Search().Enabled);
            return new XPOD_ActivitesTab_Page(driver);
        }

        public XPOD_ActivitesTab_Page saveNotify()
        {

            CommonMethods.Page_Scolldown(driver);
            Thread.Sleep(10000);
            new XPOD_Genral_OI_Page(driver).Btn_SaveAndNotify().Click();
            Thread.Sleep(10000);
            CommonMethods.Page_ScrollUp(driver);
            Thread.Sleep(10000);
            new XPOD_General_StaticEle_Page(driver).Clicking_ActivitesTab();
            Thread.Sleep(10000);
            Assert.True(Table_Activites().Displayed);
            Assert.NotEqual(0, Rowcount_ActivityTable());
            Assert.NotEqual(Rowcount_ActivityTable(),Rowcount_ActivityTable() + 1);
            return new XPOD_ActivitesTab_Page(driver);
        }

        public XPOD_ActivitesTab_Page viewSub()
        {

            CommonMethods.Page_Scolldown(driver);
            Thread.Sleep(10000);
            new XPOD_Genral_OI_Page(driver).Btn_ViewSubmission().Click();
            Thread.Sleep(30000);
            driver.SwitchTo().Window(driver.WindowHandles.Last()).Manage().Window.Maximize();
            Thread.Sleep(10000);
            Assert.True(new XPOD_ViewSubmissionPage(driver).xPODForm().Enabled);
            return new XPOD_ActivitesTab_Page(driver);
        }
    }
}
