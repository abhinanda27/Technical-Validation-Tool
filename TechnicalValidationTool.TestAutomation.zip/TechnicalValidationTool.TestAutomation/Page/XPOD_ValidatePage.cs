﻿using System;
using System.Collections.Generic;
using System.Text;
using System.Threading;
using OpenQA.Selenium;
using OpenQA.Selenium.Firefox;
using OpenQA.Selenium.Support.UI;
using TechnicalValidationTool.TestAutomation.Base;
using TechnicalValidationTool.TestAutomation.CommonMethod;
using TechnicalValidationTool.TestAutomation.Helper;
using Xunit;
using System.Linq;
namespace TechnicalValidationTool.TestAutomation.Page
{
    public class XPOD_ValidatePage: PageBase
    {
        public IWebDriver driver;

        public XPOD_ValidatePage(IWebDriver driverinstance)
        {
            driver = driverinstance;
        }

        public IWebElement commentsArea()
        {

           return driver.FindElement(By.Id("txtComments"));
            

        }

        public IWebElement approveBtn()
        {
            return driver.FindElement(By.Id("btnApprove1"));

         }

        public IWebElement pendingBtn()
        {
            return driver.FindElement(By.Id("btnPending"));

        }

        public IWebElement deniedBtn()
        {
            return driver.FindElement(By.Id("btnDeny"));

        }

        public IWebElement cancelledBtn()
        {
            return driver.FindElement(By.Id("btnCancel"));

        }

        public IWebElement releaseCossacks()
        {
            return driver.FindElement(By.XPath("//*[@id='tblMain']/tbody/tr[5]/td/input[5]"));

        }

        public IWebElement addCommentsBtn()
        {
            return driver.FindElement(By.Id("btnComments"));

        }

        public IWebElement exitBtn()
        {
            return driver.FindElement(By.XPath("//*[@id='tblMain']/tbody/tr[5]/td/input[7]")); ;

        }

        #region Actions

        public XPOD_ValidatePage validateXPOD()
        {
            CommonMethods.Page_Scolldown(driver);
            Thread.Sleep(10000);
            new XPOD_Genral_OI_Page(driver).Btn_Validate().Click();
            Thread.Sleep(20000);
            driver.SwitchTo().Window(driver.WindowHandles.Last()).Manage().Window.Maximize();
            Thread.Sleep(10000);
            CommonMethods.Page_Scolldown(driver);
            Thread.Sleep(10000);
            Assert.True(new XPOD_ValidatePage(driver).deniedBtn().Displayed);
            Assert.True(new XPOD_ValidatePage(driver).approveBtn().Displayed);
            Assert.True(new XPOD_ValidatePage(driver).cancelledBtn().Displayed);
            Assert.True(new XPOD_ValidatePage(driver).pendingBtn().Displayed);
            Assert.True(new XPOD_ValidatePage(driver).releaseCossacks().Displayed);
            Assert.True(new XPOD_ValidatePage(driver).addCommentsBtn().Displayed);
            Assert.True(new XPOD_ValidatePage(driver).exitBtn().Displayed);
            return new XPOD_ValidatePage(driver);
        }
        #endregion


    }
}
