﻿using OpenQA.Selenium;
using OpenQA.Selenium.Chrome;
using OpenQA.Selenium.Firefox;
using System;
using System.Collections.Generic;
using System.Text;

namespace TechnicalValidationTool.TestAutomation.Base
{
    public class TestBase:IDisposable
    {

        public IWebDriver webDriverTest;
        public TestBase()
        {

            webDriverTest = new ChromeDriver(@"C:\driver");
            

        }     

        public void Dispose()
        {
            webDriverTest.Quit();
        }
    }
}
